#ifndef JSJ_H__
#define JSJ_H__

#define STACK_SIZE 100 /*ջ��С*/
#define TOP_OF_STACK -1 /*ջ��λ��*/
typedef int ElementType; /*ջԪ������*/

#define SUCCESS 0
#define FAILURE -1

/*����ջ�ṹ*/
typedef struct StackInfo
{
    int topOfStack; /*��¼ջ��λ��*/
    ElementType stack[STACK_SIZE]; /*ջ���飬Ҳ����ʹ�ö�̬����ʵ��*/
}StackInfo_st;



int stack_push(StackInfo_st* s, ElementType value);
int stack_pop(StackInfo_st* s, ElementType* value);
int stack_top(StackInfo_st* s, ElementType* value);
int stack_is_full(StackInfo_st* s);
int stack_is_empty(StackInfo_st* s);
int calcOp(StackInfo_st* nums, StackInfo_st* ops, int nowOp);
int calc(const char* exp, int* result);
int priorityCompare(char op1, char op2);
void priorityInit();






#endif
